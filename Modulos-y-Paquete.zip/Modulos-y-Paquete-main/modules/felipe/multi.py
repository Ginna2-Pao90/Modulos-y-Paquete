def multiplicar():
    num1 = int(input("Primer numero: "))
    num2 = int(input("Segundo numero: "))
    resultado = num1 * num2
    print("El resultado de la multiplicacion es: ", resultado)
