def operacion():
        number1 = int(input("Primer numero: "))
        number2 = int(input("Segundo numero: "))
        d = number1 + number2
        print("La suma de los numeros son: ", d)