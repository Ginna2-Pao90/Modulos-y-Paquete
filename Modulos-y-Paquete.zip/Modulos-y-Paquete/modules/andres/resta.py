def resta():
    num1 = float(input("Digite el primer numero: "))
    num2 = float(input("Digite el segundo nombre: "))
    result = num1 - num2
    print("La resta de los números son: ", result)
