from menu import principal
if __name__ == '__main__':
    principal()